/**
 * Maclovia / Belleza Maldita — Main Native Orchestrator
 * Arquitectura Vanilla • Cero React • Cero Framer Motion
 */

import { initI18n, getLanguage } from './i18n.js';
import { initMockupTabs, copyTextToClipboard } from './mockups.js';
import { PROJECTS } from './data/projects.js';
import { CEO_PROFILE } from './data/team.js';

// --- Theme Management (Dark / Light) ---
function initTheme() {
  const savedTheme = localStorage.getItem('maclovia_theme') || 'dark';
  applyTheme(savedTheme);

  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
    });
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('maclovia_theme', theme);

  const iconUse = document.querySelector('#theme-toggle-btn use');
  if (iconUse) {
    iconUse.setAttribute('href', theme === 'dark' ? 'assets/icons/sprite.svg#icon-sun' : 'assets/icons/sprite.svg#icon-moon');
  }
}

// --- Brand Mode Switcher (Unified / Maclovia / Belleza Maldita) ---
const BRAND_MODES = ['unified', 'maclovia', 'belleza'];
let currentBrandMode = 'unified';

function setBrandMode(mode) {
  if (!BRAND_MODES.includes(mode)) return;
  currentBrandMode = mode;

  // Update hero views
  document.querySelectorAll('.brand-view').forEach((view) => {
    view.classList.remove('active');
  });
  const activeView = document.getElementById(`brand-view-${mode}`);
  if (activeView) {
    activeView.classList.add('active');
  }

  // Update pills
  document.querySelectorAll('.brand-switch-btn').forEach((btn) => {
    if (btn.getAttribute('data-brand-mode') === mode) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Update header button label
  const modeLabel = document.getElementById('brand-mode-label');
  if (modeLabel) {
    modeLabel.textContent = mode.toUpperCase();
  }
}

function initBrandSwitcher() {
  document.querySelectorAll('.brand-switch-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const mode = btn.getAttribute('data-brand-mode');
      setBrandMode(mode);
    });
  });

  const headerModeBtn = document.getElementById('brand-mode-btn');
  if (headerModeBtn) {
    headerModeBtn.addEventListener('click', () => {
      const currentIndex = BRAND_MODES.indexOf(currentBrandMode);
      const nextIndex = (currentIndex + 1) % BRAND_MODES.length;
      setBrandMode(BRAND_MODES[nextIndex]);
    });
  }
}

// --- Live CDMX Clock ---
function initCdmxClock() {
  const clockEl = document.getElementById('footer-cdmx-clock');
  if (!clockEl) return;

  const updateTime = () => {
    try {
      const timeStr = new Intl.DateTimeFormat('es-MX', {
        timeZone: 'America/Mexico_City',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).format(new Date());
      clockEl.textContent = `${timeStr} CST`;
    } catch {
      clockEl.textContent = new Date().toLocaleTimeString();
    }
  };

  updateTime();
  setInterval(updateTime, 1000);
}

// --- Back to Top Button ---
function initBackToTop() {
  const btn = document.getElementById('btn-back-to-top');
  if (btn) {
    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
}

// --- Render Portfolio Projects with Expandable Architecture Specs ---
function renderProjects(filter = 'all') {
  const container = document.getElementById('portfolio-grid-container');
  if (!container) return;

  const currentLang = getLanguage();
  const isEn = currentLang === 'en';

  const filtered = filter === 'all' 
    ? PROJECTS 
    : PROJECTS.filter((p) => p.category === filter);

  const countEl = document.getElementById('portfolio-project-count');
  if (countEl) {
    countEl.textContent = `${filtered.length} ${isEn ? 'certified modules' : 'módulos certificados'}`;
  }

  container.innerHTML = filtered.map((p) => {
    const arch = p.architectureDetails;
    const highlights = isEn ? arch.highlightsEn : arch.highlightsEs;

    return `
      <div class="project-card" data-category="${p.category}" id="project-card-${p.id}">
        <div>
          <div class="project-badge">
            ${isEn ? p.badgeCategoryEn : p.badgeCategoryEs}
          </div>
          <h4 class="project-title">${p.name}</h4>
          <p class="project-desc">${isEn ? p.descriptionEn : p.descriptionEs}</p>
          
          <!-- Terminal Command Box -->
          <div class="terminal-box">
            <code>${p.cloneCmd}</code>
            <button class="copy-btn" data-copy-text="${p.cloneCmd}" title="Copiar comando">
              <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-copy"></use></svg>
            </button>
          </div>

          <!-- Tech Stack Tags -->
          <div class="ceo-specialties" style="margin-bottom: 1rem;">
            ${p.techStack.map((tech) => `<span class="specialty-pill">${tech}</span>`).join('')}
          </div>

          <!-- Architecture Specs Toggle Button -->
          <button class="btn btn-ghost" data-toggle-arch="${p.id}" style="width: 100%; justify-content: space-between; padding: 0.4rem 0.75rem; margin-bottom: 0.75rem;">
            <span style="display: flex; align-items: center; gap: 0.4rem; color: var(--color-rosa-chilango);">
              <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-cpu"></use></svg>
              <span>${isEn ? 'Architecture & Benchmarks' : 'Arquitectura & Métricas'}</span>
            </span>
            <svg class="icon icon-stroke text-rosa"><use href="assets/icons/sprite.svg#icon-arrow-down"></use></svg>
          </button>

          <!-- Collapsible Architecture Specs Drawer -->
          <div class="architecture-drawer" id="arch-drawer-${p.id}">
            <div style="color: var(--text-primary); margin-bottom: 0.35rem;">
              <strong class="text-rosa">Runtime:</strong> ${arch.runtime}
            </div>
            <div style="color: var(--text-primary); margin-bottom: 0.35rem;">
              <strong class="text-rosa">Throughput:</strong> ${arch.throughput}
            </div>
            <div style="color: var(--text-secondary); margin-bottom: 0.5rem;">
              <strong class="text-rosa">Format / Quant:</strong> ${arch.quantizationOrType}
            </div>

            <!-- Highlights -->
            <ul style="list-style: none; padding-left: 0; margin-bottom: 0.75rem; display: flex; flex-direction: column; gap: 0.25rem;">
              ${highlights.map((h) => `
                <li style="display: flex; align-items: flex-start; gap: 0.35rem; color: var(--text-muted); font-size: 0.65rem;">
                  <span class="text-rosa">✦</span>
                  <span>${h}</span>
                </li>
              `).join('')}
            </ul>

            <!-- Benchmarks Grid -->
            ${arch.benchmarks ? `
              <div class="benchmark-badge-grid">
                ${arch.benchmarks.map((b) => `
                  <div class="benchmark-pill">
                    <div style="color: var(--color-rosa-chilango); font-weight: 700; font-size: 0.75rem;">${b.value}</div>
                    <div style="font-size: 0.6rem; color: var(--text-primary);">${b.label}</div>
                    <div style="font-size: 0.55rem; color: var(--text-muted);">${b.subtext}</div>
                  </div>
                `).join('')}
              </div>
            ` : ''}
          </div>
        </div>

        <!-- Action Links -->
        <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--border-subtle); padding-top: 1rem; margin-top: 1rem;">
          <a href="${p.githubUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-ghost" style="padding: 0.35rem 0.75rem;">
            <svg class="icon"><use href="assets/icons/sprite.svg#icon-github"></use></svg>
            <span>GitHub</span>
            <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-arrow-up-right"></use></svg>
          </a>

          ${p.demoUrl ? `
            <a href="${p.demoUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary" style="padding: 0.35rem 0.75rem;">
              <span>Demo</span>
              <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-arrow-up-right"></use></svg>
            </a>
          ` : ''}

          ${p.huggingFaceUrl ? `
            <a href="${p.huggingFaceUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary" style="padding: 0.35rem 0.75rem;">
              <svg class="icon"><use href="assets/icons/sprite.svg#icon-cpu"></use></svg>
              <span>Hugging Face</span>
            </a>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');

  // Attach drawer toggles
  container.querySelectorAll('[data-toggle-arch]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-toggle-arch');
      const drawer = document.getElementById(`arch-drawer-${id}`);
      if (drawer) {
        drawer.classList.toggle('open');
        btn.classList.toggle('open');
      }
    });
  });
}

// --- Portfolio Filter Controls ---
function initPortfolioFilters() {
  const filterBtns = document.querySelectorAll('[data-filter]');
  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('btn-primary'));
      filterBtns.forEach((b) => b.classList.add('btn-secondary'));
      btn.classList.remove('btn-secondary');
      btn.classList.add('btn-primary');

      const category = btn.getAttribute('data-filter');
      renderProjects(category);
    });
  });
}

// --- Render CEO Card ---
function renderCeoProfile() {
  const container = document.getElementById('ceo-profile-container');
  if (!container) return;

  const isEn = getLanguage() === 'en';

  container.innerHTML = `
    <div class="ceo-card">
      <div class="ceo-grid">
        <!-- Top bar -->
        <div class="ceo-topbar">
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <span class="ceo-badge">
              ${isEn ? CEO_PROFILE.roleEn : CEO_PROFILE.roleEs}
            </span>
            <span class="font-mono text-muted" style="font-size: 0.65rem; display: flex; align-items: center; gap: 0.35rem;">
              <svg class="icon icon-stroke text-rosa"><use href="assets/icons/sprite.svg#icon-map-pin"></use></svg>
              ${CEO_PROFILE.location}
            </span>
          </div>

          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <a href="https://github.com/${CEO_PROFILE.githubHandle}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary">
              <svg class="icon"><use href="assets/icons/sprite.svg#icon-github"></use></svg>
              <span>@${CEO_PROFILE.githubHandle}</span>
              <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-arrow-up-right"></use></svg>
            </a>

            <a href="mailto:${CEO_PROFILE.email}" class="btn btn-primary">
              <svg class="icon icon-stroke"><use href="assets/icons/sprite.svg#icon-mail"></use></svg>
              <span>${isEn ? 'Executive Contact' : 'Contacto Ejecutivo'}</span>
            </a>
          </div>
        </div>

        <!-- Main avatar + info -->
        <div class="ceo-main">
          <div class="ceo-avatar-wrap">
            <img src="https://avatars.githubusercontent.com/u/8192280?v=4" alt="${CEO_PROFILE.name}" class="ceo-avatar" />
            <span class="ceo-tag">CEO</span>
          </div>

          <div class="ceo-details">
            <h3>${CEO_PROFILE.name}</h3>
            <p class="ceo-role-title">${isEn ? CEO_PROFILE.roleEn : CEO_PROFILE.roleEs}</p>
            <p class="ceo-bio">${isEn ? CEO_PROFILE.bioEn : CEO_PROFILE.bioEs}</p>
            
            <div class="ceo-specialties">
              ${CEO_PROFILE.specialties.map((spec) => `<span class="specialty-pill">${spec}</span>`).join('')}
            </div>
          </div>
        </div>

        <!-- Footer metrics -->
        <div class="ceo-footer">
          <div class="ceo-metrics">
            <div>
              <div class="metric-val">${CEO_PROFILE.metrics.experience}</div>
              <div class="metric-lbl">${isEn ? CEO_PROFILE.metrics.experienceLabelEn : CEO_PROFILE.metrics.experienceLabelEs}</div>
            </div>
            <div>
              <div class="metric-val" style="color: var(--text-primary);">${CEO_PROFILE.metrics.systems}</div>
              <div class="metric-lbl">${isEn ? CEO_PROFILE.metrics.systemsLabelEn : CEO_PROFILE.metrics.systemsLabelEs}</div>
            </div>
            <div>
              <div class="metric-val" style="color: var(--text-secondary);">${CEO_PROFILE.metrics.focus}</div>
              <div class="metric-lbl">${isEn ? CEO_PROFILE.metrics.focusLabelEn : CEO_PROFILE.metrics.focusLabelEs}</div>
            </div>
          </div>

          <a href="#portfolio-section" class="btn btn-secondary">
            <svg class="icon icon-stroke text-rosa"><use href="assets/icons/sprite.svg#icon-briefcase"></use></svg>
            <span>${isEn ? 'View Engineering Portfolio' : 'Ver Portafolio de Ingeniería'}</span>
            <svg class="icon icon-stroke text-rosa"><use href="assets/icons/sprite.svg#icon-arrow-down"></use></svg>
          </a>
        </div>
      </div>
    </div>
  `;
}

// --- Standalone SVG Generation & Toolkit Workbench ---
const MACLOVIA_SVG_RAW = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
  <defs>
    <linearGradient id="maclovia-m-grad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FF3B9D" />
      <stop offset="100%" stop-color="#E4007C" />
    </linearGradient>
    <linearGradient id="pentagon-stroke-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF3B9D" />
      <stop offset="100%" stop-color="#A50058" />
    </linearGradient>
  </defs>
  <!-- Outer Pentagonal Contour Shield -->
  <polygon points="100,16 182,76 151,174 49,174 18,76" fill="#070707" stroke="url(#pentagon-stroke-grad)" stroke-width="4.5" stroke-linejoin="round" />
  <!-- Inner Accent Pentagon Contour -->
  <polygon points="100,32 168,82 142,162 58,162 32,82" fill="none" stroke="#E4007C" stroke-width="1.75" stroke-dasharray="5 3.5" opacity="0.65" stroke-linejoin="round" />
  <!-- 5 Vertex Pivot Nodes -->
  <circle cx="100" cy="16" r="3.5" fill="#E4007C" />
  <circle cx="182" cy="76" r="3.5" fill="#E4007C" />
  <circle cx="151" cy="174" r="3.5" fill="#E4007C" />
  <circle cx="49" cy="174" r="3.5" fill="#E4007C" />
  <circle cx="18" cy="76" r="3.5" fill="#E4007C" />
  <!-- Central Editorial "M" Monogram -->
  <text x="100" y="137" font-family="'Abril Fatface', Georgia, 'Times New Roman', serif" font-size="82" font-weight="900" fill="url(#maclovia-m-grad)" text-anchor="middle" letter-spacing="-1">M</text>
</svg>`;

function initSvgToolkitWorkbench() {
  const previewSvg = document.getElementById('toolkit-interactive-svg');
  const sizeBtns = document.querySelectorAll('[data-svg-size]');
  const animToggleBtn = document.getElementById('toolkit-anim-toggle');
  const downloadBtn = document.getElementById('toolkit-download-btn');
  const copyXmlBtn = document.getElementById('toolkit-copy-xml-btn');
  const codeTabs = document.querySelectorAll('.toolkit-code-tab-btn');
  const codePreview = document.getElementById('toolkit-code-display');

  let currentSize = 96;
  let isAnimated = true;
  let currentCodeTab = 'xml';

  const updatePreview = () => {
    if (previewSvg) {
      previewSvg.style.width = `${currentSize}px`;
      previewSvg.style.height = `${currentSize}px`;
      if (isAnimated) {
        previewSvg.classList.add('glow-rosa', 'animate-pulse-glow');
      } else {
        previewSvg.classList.remove('glow-rosa', 'animate-pulse-glow');
      }
    }
  };

  const updateCodeDisplay = () => {
    if (!codePreview) return;
    if (currentCodeTab === 'xml') {
      codePreview.textContent = MACLOVIA_SVG_RAW;
    } else {
      codePreview.textContent = `<!-- Embeber en cualquier HTML5 Vanilla -->\n<div class="brand-symbol" style="width: ${currentSize}px; height: ${currentSize}px;">\n  ${MACLOVIA_SVG_RAW.trim()}\n</div>`;
    }
  };

  // Size buttons
  sizeBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      sizeBtns.forEach((b) => b.classList.remove('active', 'btn-primary'));
      sizeBtns.forEach((b) => b.classList.add('btn-secondary'));
      btn.classList.remove('btn-secondary');
      btn.classList.add('btn-primary', 'active');
      currentSize = parseInt(btn.getAttribute('data-svg-size'), 10) || 96;
      updatePreview();
      updateCodeDisplay();
    });
  });

  const updateAnimBtnText = () => {
    if (!animToggleBtn) return;
    const isEn = getLanguage() === 'en';
    animToggleBtn.textContent = isAnimated 
      ? (isEn ? 'Animation: Active' : 'Animación: Activa') 
      : (isEn ? 'Animation: Static' : 'Animación: Estática');
  };

  // Animation Toggle
  if (animToggleBtn) {
    animToggleBtn.addEventListener('click', () => {
      isAnimated = !isAnimated;
      updateAnimBtnText();
      updatePreview();
    });
  }

  // Direct SVG Blob Download
  if (downloadBtn) {
    downloadBtn.addEventListener('click', () => {
      const blob = new Blob([MACLOVIA_SVG_RAW], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `maclovia-mark-${currentSize}px.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // Copy XML to clipboard
  if (copyXmlBtn) {
    copyXmlBtn.addEventListener('click', () => {
      copyTextToClipboard(MACLOVIA_SVG_RAW, copyXmlBtn);
    });
  }

  // Code tabs
  codeTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      codeTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      currentCodeTab = tab.getAttribute('data-code-tab');
      updateCodeDisplay();
    });
  });

  updatePreview();
  updateCodeDisplay();
}

// --- App Bootstrap ---
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initI18n();
  initBrandSwitcher();
  initCdmxClock();
  initBackToTop();
  initMockupTabs();
  initPortfolioFilters();
  initSvgToolkitWorkbench();

  renderCeoProfile();
  renderProjects('all');

  window.addEventListener('languagechange', () => {
    renderCeoProfile();
    const activeFilterBtn = document.querySelector('[data-filter].btn-primary');
    const filter = activeFilterBtn ? activeFilterBtn.getAttribute('data-filter') : 'all';
    renderProjects(filter);

    const animToggleBtn = document.getElementById('toolkit-anim-toggle');
    if (animToggleBtn) {
      const isEn = getLanguage() === 'en';
      const isAnimated = animToggleBtn.textContent.includes('Activa') || animToggleBtn.textContent.includes('Active');
      animToggleBtn.textContent = isAnimated 
        ? (isEn ? 'Animation: Active' : 'Animación: Activa') 
        : (isEn ? 'Animation: Static' : 'Animación: Estática');
    }
  });
});
